﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            txtResultTrian.Clear();

            txtLadoA.Focus();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            Double ladoA, ladoB, ladoC, tipoTrian;

            if (Double.TryParse(txtLadoA.Text, out ladoA) && Double.TryParse(txtLadoB.Text, out ladoB) && 
                Double.TryParse(txtLadoC.Text, out ladoC))
            {
                if (ladoA < (ladoB + ladoC) && ladoA > Math.Abs(ladoB - ladoC) &&
                    ladoB < (ladoA + ladoC) && ladoB > Math.Abs(ladoA - ladoC) &&
                    ladoC < (ladoA + ladoB) && ladoC > Math.Abs(ladoA - ladoB))
                {
                    if(ladoA == ladoB && ladoB == ladoC)
                    {
                        txtResultTrian.Text = "TRIÂNGULO EQUILATERO!";
                    }
                    else if ((ladoA == ladoB || ladoA == ladoC || ladoB == ladoC))
                    {
                        txtResultTrian.Text = "TRIÂNGULO ISÓSCELES!";
                    }
                    else
                    {
                        txtResultTrian.Text = "TRIÂNGULO ESCALENO!";
                    }
                }
                else
                {
                    txtResultTrian.Text = "NÃO É UM TRIÂNGULO!";
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos!");
                txtLadoA.Focus();
            }
        }
    }
}
