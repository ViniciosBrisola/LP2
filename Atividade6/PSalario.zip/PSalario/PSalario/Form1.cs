﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double descontoIRPF = 0;
            double descontoINSS = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;
            double salarioLiquido = 0;

            if (txtNomeFuncionario.Text == String.Empty)
            {
                MessageBox.Show("O nome do funcionário \n não pode ser vazio");
            }
            else
            {
                if (!double.TryParse(mskbxSalarioBruto.Text, out salarioBruto)
                    || !double.TryParse(cbxNumeroFilhos.Text, out numeroFilhos))
                {
                    MessageBox.Show("Salário bruto e números de filhos \n devem ser números");
                }
                else
                {
                    if (salarioBruto <= 0)
                    {
                        MessageBox.Show("Salário deve ser maior que zero!");
                    }
                    else
                    {
                        //Cálculo INSS
                        if (salarioBruto <= 800.47)
                        {
                            mskbxAliqINSS.Text = "7,65%";
                            descontoINSS = (7.65 / 100) * salarioBruto;
                        }
                        else if (salarioBruto <= 1050)
                        {
                            mskbxAliqINSS.Text = "8,65%";
                            descontoINSS = (8.65 / 100) * salarioBruto;
                        }
                        else if (salarioBruto <= 1400.77)
                        {
                            mskbxAliqINSS.Text = "9,00%";
                            descontoINSS = (9.00 / 100) * salarioBruto;
                        }
                        else if (salarioBruto <= 2801.56)
                        {
                            mskbxAliqINSS.Text = "11,00%";
                            descontoINSS = (11.00 / 100) * salarioBruto;
                        }
                        else
                        {
                            mskbxAliqINSS.Text = "Teto";
                            descontoINSS = 308.17;
                        }

                        mskbxDescontoINSS.Text = descontoINSS.ToString("N2");

                        //Cálculo IRPF
                        if (salarioBruto <= 1257.12)
                        {
                            mskbxAliqIRPF.Text = "Isento";
                            descontoIRPF = 0.00;
                        }
                        else if (salarioBruto <= 2512.08)
                        {
                            mskbxAliqIRPF.Text = "15,00%";
                            descontoIRPF = (15.00 / 100) * salarioBruto;
                        }
                        else
                        {
                            mskbxAliqIRPF.Text = "27,50%";
                            descontoIRPF = (27.50 / 100) * salarioBruto;
                        }

                        mskbxDescontoIRPF.Text = descontoIRPF.ToString("N2");

                        //Salario Familia
                        if (numeroFilhos > 0)
                        {
                            if (salarioBruto <= 435.52)
                            {
                                salarioFamilia = 22.33 * numeroFilhos;
                            }
                            else if (salarioBruto <= 654.61)
                            {
                                salarioFamilia = 15.74 * numeroFilhos;
                            }
                            else
                            {
                                salarioFamilia = 0;
                            }
                        }

                        mskbxSalarioFamilia.Text = salarioFamilia.ToString("N2");

                        salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                        mskbxSalarioLiq.Text = salarioLiquido.ToString("N2");
                    }

                }
            }
        }
    }
}
