﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2Calc
{
    public partial class Calculadora : Form
    {
        public Calculadora()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResult.Clear();

            txtNum1.Focus();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            Double num1, num2, result;

            if (Double.TryParse(txtNum1.Text, out num1) && Double.TryParse(txtNum2.Text, out num2))
            {
                result = num1 + num2;
                txtResult.Text = result.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores inseridos são inválidos!");
                txtNum1.Focus();
            }
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Double num1, num2, result;

            if (Double.TryParse(txtNum1.Text, out num1) && Double.TryParse(txtNum2.Text, out num2))
            {
                result = num1 - num2;
                txtResult.Text = result.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores inseridos são inválidos!");
                txtNum1.Focus();
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            Double num1, num2, result;

            if (Double.TryParse(txtNum1.Text, out num1) && Double.TryParse(txtNum2.Text, out num2))
            {
                result = num1 * num2;
                txtResult.Text = result.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores inseridos são inválidos!");
                txtNum1.Focus();
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            Double num1, num2, result;

            if (Double.TryParse(txtNum1.Text, out num1) && Double.TryParse(txtNum2.Text, out num2))
            {
                if ((num2 == 0) || (num1 == 0 && num2 == 0))
                {
                    MessageBox.Show("Cálculo impossível\nValores inválidos!");
                    txtNum1.Focus();
                }
                else
                {
                    result = num1 / num2;
                    txtResult.Text = result.ToString("N2");
                }
            }
            else
            {
                MessageBox.Show("Valores inseridos são inválidos!");
                txtNum1.Focus();
            }
        }
    }
}
