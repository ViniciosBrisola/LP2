﻿namespace Pmetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQtdAlfabetico = new System.Windows.Forms.Button();
            this.btnLocalizaEspaco = new System.Windows.Forms.Button();
            this.btnQtdNum = new System.Windows.Forms.Button();
            this.rtxtTexto = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnQtdAlfabetico
            // 
            this.btnQtdAlfabetico.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQtdAlfabetico.Location = new System.Drawing.Point(382, 164);
            this.btnQtdAlfabetico.Name = "btnQtdAlfabetico";
            this.btnQtdAlfabetico.Size = new System.Drawing.Size(105, 51);
            this.btnQtdAlfabetico.TabIndex = 20;
            this.btnQtdAlfabetico.Text = "Qtde Alfabéticos";
            this.btnQtdAlfabetico.UseVisualStyleBackColor = true;
            this.btnQtdAlfabetico.Click += new System.EventHandler(this.btnQtdAlfabetico_Click);
            // 
            // btnLocalizaEspaco
            // 
            this.btnLocalizaEspaco.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocalizaEspaco.Location = new System.Drawing.Point(248, 164);
            this.btnLocalizaEspaco.Name = "btnLocalizaEspaco";
            this.btnLocalizaEspaco.Size = new System.Drawing.Size(105, 51);
            this.btnLocalizaEspaco.TabIndex = 19;
            this.btnLocalizaEspaco.Text = "Localizar Espaço";
            this.btnLocalizaEspaco.UseVisualStyleBackColor = true;
            this.btnLocalizaEspaco.Click += new System.EventHandler(this.btnLocalizaEspaco_Click);
            // 
            // btnQtdNum
            // 
            this.btnQtdNum.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQtdNum.Location = new System.Drawing.Point(123, 164);
            this.btnQtdNum.Name = "btnQtdNum";
            this.btnQtdNum.Size = new System.Drawing.Size(105, 51);
            this.btnQtdNum.TabIndex = 18;
            this.btnQtdNum.Text = "Qtde Numéricos";
            this.btnQtdNum.UseVisualStyleBackColor = true;
            this.btnQtdNum.Click += new System.EventHandler(this.btnQtdNum_Click);
            // 
            // rtxtTexto
            // 
            this.rtxtTexto.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtTexto.Location = new System.Drawing.Point(123, 31);
            this.rtxtTexto.Name = "rtxtTexto";
            this.rtxtTexto.Size = new System.Drawing.Size(364, 110);
            this.rtxtTexto.TabIndex = 21;
            this.rtxtTexto.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LimeGreen;
            this.ClientSize = new System.Drawing.Size(604, 265);
            this.Controls.Add(this.rtxtTexto);
            this.Controls.Add(this.btnQtdAlfabetico);
            this.Controls.Add(this.btnLocalizaEspaco);
            this.Controls.Add(this.btnQtdNum);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnQtdAlfabetico;
        private System.Windows.Forms.Button btnLocalizaEspaco;
        private System.Windows.Forms.Button btnQtdNum;
        private System.Windows.Forms.RichTextBox rtxtTexto;
    }
}